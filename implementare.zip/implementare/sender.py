from functii_rpm import *

import socket
import time
import random

id = []
id.append('635c0d29ee37c5035802e58e3218e717b8e4f5e02b235c52f657ba9a48da2b65')
id.append('c1dac499636041d755893b1ec4c33862e431b01d92855b1a606de684abcc4b14')


def criptare_msg(msg): #id[0] si id[1] - pe 256 biti 64 hexa
    #returneaza (ors, ct)
    global id
    s = gen_s()
    ors = add_mod(s, id[0])
    idtemp = pdaf(id[1], s)
    w = ocw(idtemp)
    #aes
    ct = cript_aes(w, msg)

    id[0] = pdaf(s, id[1])
    print('Noul ID1: ' + id[0])
    id[1] = pdaf(id[1], id[0])
    print('Noul ID2: ' + id[1])
    print('')
    print('Cheia: ' + w)

    str = ors + ct
    return str


mesaj = 'mesajul nr. '

clientsocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
clientsocket.connect(('localhost', 8089))
for i in range(0, 10):
    numar = str(random.randint(1000, 9999))
    pachet = criptare_msg(mesaj+numar)
    clientsocket.send(pachet)
    print('Trimis: ' + mesaj+numar)
    print('')
    time.sleep(2)

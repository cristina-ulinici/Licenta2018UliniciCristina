from functii_rpm import *

import socket

id = []
id.append('635c0d29ee37c5035802e58e3218e717b8e4f5e02b235c52f657ba9a48da2b65')
id.append('c1dac499636041d755893b1ec4c33862e431b01d92855b1a606de684abcc4b14')

def decriptare_msg(data):
    global id
    ors = data[0]
    ct = data[1]
    s = add_modd(ors, id[0])
    idtemp = pdaf(id[1], s)
    w = ocw(idtemp)
    msg = decript_aes(w, ct)

    id[0] = pdaf(s, id[1])
    print('Noul ID1: ' + id[0])
    id[1] = pdaf(id[1], id[0])
    print('Noul ID2: ' + id[1])
    print('')
    print('Cheia: ' + w)

    return msg

serversocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
serversocket.bind(('localhost', 8089))
serversocket.listen(1)

connection, address = serversocket.accept()
while True:
    re = connection.recv(200)
    data = []
    data.append(re[:64])
    data.append(re[64:])

    mesaj = decriptare_msg(data)
    print('Primit: ' + mesaj)
    print('')

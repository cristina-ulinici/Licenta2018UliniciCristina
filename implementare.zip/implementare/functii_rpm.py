import random as r
from Crypto.Cipher import AES
from Crypto import Random
from Crypto.Util import Counter


def hex_to_ints(x): #pot sa adaug pentru litere mari
    y = []
    for c in x:
        if (c<='9' and c>='0'):
            y.append(int(c))
        elif(c>='a' and c<='f'):
            y.append(ord(c)-87)

    return y

def ints_to_hex(y):
    x = ""
    for c in y:
        if (c>=0 and c<=9):
            x += str(c)
        else:
            x += chr(c+87)

    return x

def pdaf(x, y):
    x = hex_to_ints(x)
    y = hex_to_ints(y)
    if (len(x)!=len(y)):
        exit()
    n = len(x)
    z = []
    for i in range(1, n+1):
        temp = ((i+y[i-1])%n + 1)%n
        temp = (x[temp-1] + x[i-1])%16
        z.append(temp)

    return ints_to_hex(z)

def ocw(x):
    y = []
    n = len(x)//2
    a = hex_to_ints(x[:n])
    b = hex_to_ints(x[n:])
    for i in range(0, n):
        y.append((a[i]+b[i])%16)

    return ints_to_hex(y)

# genereaza s random pe 256 biti
def gen_s():
    s = []
    for i in range(0, 64):
        temp = r.randint(0,15)
        s.append(temp)

    return ints_to_hex(s)

def cript_aes(key, msg):
    ctr = Counter.new(128)
    cipher = AES.new(key, AES.MODE_CTR, counter=ctr)
    ct = cipher.encrypt(msg)
    return ct

def decript_aes(key, ct):
    ctr = Counter.new(128)
    cipher = AES.new(key, AES.MODE_CTR, counter=ctr)
    msg = cipher.decrypt(ct)
    return msg

def gen_ids():
    id1 = gen_s()
    id2 = gen_s()
    ids = []
    ids.append(id1)
    ids.append(id2)

    return ids

# id = gen_ids()

def add_mod(x,y):
    x = hex_to_ints(x)
    y = hex_to_ints(y)
    rez = []

    for i in range(0, len(x)):
        rez.append((x[i]+y[i])%16)

    return ints_to_hex(rez)

def add_modd(x,y):
    #x-y
    x = hex_to_ints(x)
    y = hex_to_ints(y)
    z = []

    for i in range(0, len(x)):
        temp = ((16+x[i])-y[i])%16
        z.append(temp)

    return ints_to_hex(z)
